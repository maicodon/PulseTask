"use strict";

    class TaskManager {
      constructor() {
        this.storageKey = "taskflow.tasks.v1";
        this.tasks = this.loadTasksFromStorage();
        this.filter = "all";
        this.searchTerm = "";
        this.editingId = null;
        this.draggedId = null;
        this.toastTimer = null;

        this.el = {
          form: document.querySelector("#taskForm"),
          title: document.querySelector("#taskTitle"),
          category: document.querySelector("#taskCategory"),
          dueDate: document.querySelector("#taskDueDate"),
          customWrap: document.querySelector("#customCategoryWrap"),
          customCategory: document.querySelector("#customCategory"),
          search: document.querySelector("#searchInput"),
          list: document.querySelector("#taskList"),
          empty: document.querySelector("#emptyState"),
          emptyTitle: document.querySelector("#emptyTitle"),
          emptyMessage: document.querySelector("#emptyMessage"),
          count: document.querySelector("#taskCount"),
          heading: document.querySelector("#listHeading"),
          toast: document.querySelector("#toast")
        };

        this.bindEvents();
        this.render();
      }

      loadTasksFromStorage() {
        try {
          const raw = localStorage.getItem(this.storageKey);
          if (!raw) return [];
          const parsed = JSON.parse(raw);
          if (!Array.isArray(parsed)) return [];
          return parsed.filter(task =>
            task && typeof task.id === "string" &&
            typeof task.title === "string" &&
            typeof task.category === "string" &&
            typeof task.completed === "boolean"
          ).map((task, index) => ({
            id: task.id,
            title: task.title.slice(0, 180),
            category: task.category.slice(0, 30) || "Personal",
            dueDate: typeof task.dueDate === "string" ? task.dueDate : "",
            completed: task.completed,
            createdAt: Number.isFinite(task.createdAt) ? task.createdAt : Date.now(),
            order: Number.isFinite(task.order) ? task.order : index
          })).sort((a, b) => a.order - b.order);
        } catch (error) {
          console.warn("Taskflow could not read saved tasks. Starting with an empty list.", error);
          return [];
        }
      }

      saveTasksToStorage() {
        try {
          localStorage.setItem(this.storageKey, JSON.stringify(this.tasks));
        } catch (error) {
          console.error("Taskflow could not save tasks.", error);
          this.showToast("Could not save changes in this browser.");
        }
      }

      bindEvents() {
        this.el.form.addEventListener("submit", event => {
          event.preventDefault();
          this.addTask();
        });

        this.el.category.addEventListener("change", () => {
          const custom = this.el.category.value === "custom";
          this.el.customWrap.classList.toggle("visible", custom);
          if (custom) this.el.customCategory.focus();
        });

        document.querySelectorAll("[data-filter]").forEach(button => {
          button.addEventListener("click", () => {
            this.filter = button.dataset.filter;
            document.querySelectorAll("[data-filter]").forEach(tab =>
              tab.setAttribute("aria-pressed", String(tab === button))
            );
            this.render();
          });
        });

        this.el.search.addEventListener("input", () => {
          this.searchTerm = this.el.search.value.trim().toLocaleLowerCase();
          this.render();
        });

        this.el.list.addEventListener("change", event => {
          const checkbox = event.target.closest("[data-action='toggle']");
          if (checkbox) this.toggleTask(checkbox.dataset.id, checkbox.checked);
        });

        this.el.list.addEventListener("click", event => {
          const button = event.target.closest("button[data-action]");
          if (!button) return;
          const { action, id } = button.dataset;
          if (action === "delete") this.deleteTask(id, button.closest(".task-item"));
          if (action === "edit") { this.editingId = id; this.render(); }
          if (action === "cancel-edit") { this.editingId = null; this.render(); }
          if (action === "save-edit") this.saveEdit(id);
          if (action === "move-up") this.moveTask(id, -1);
          if (action === "move-down") this.moveTask(id, 1);
        });

        this.el.list.addEventListener("submit", event => {
          if (event.target.matches(".edit-form")) {
            event.preventDefault();
            this.saveEdit(event.target.dataset.id);
          }
        });

        this.el.list.addEventListener("keydown", event => {
          if (event.key === "Escape" && this.editingId) {
            this.editingId = null;
            this.render();
          }
        });

        this.el.list.addEventListener("dragstart", event => {
          const item = event.target.closest(".task-item[draggable='true']");
          if (!item) return;
          this.draggedId = item.dataset.id;
          item.classList.add("dragging");
          event.dataTransfer.effectAllowed = "move";
          event.dataTransfer.setData("text/plain", this.draggedId);
        });

        this.el.list.addEventListener("dragover", event => {
          const target = event.target.closest(".task-item");
          if (!target || !this.draggedId || target.dataset.id === this.draggedId) return;
          event.preventDefault();
          this.el.list.querySelectorAll(".drag-over").forEach(node => node.classList.remove("drag-over"));
          target.classList.add("drag-over");
        });

        this.el.list.addEventListener("drop", event => {
          const target = event.target.closest(".task-item");
          if (!target || !this.draggedId) return;
          event.preventDefault();
          this.reorderTask(this.draggedId, target.dataset.id);
          this.clearDragState();
        });

        this.el.list.addEventListener("dragend", () => this.clearDragState());

        document.querySelector("#todayLabel").textContent =
          new Intl.DateTimeFormat(undefined, { weekday: "short", month: "short", day: "numeric", year: "numeric" }).format(new Date());
      }

      addTask() {
        const title = this.el.title.value.trim();
        const category = this.el.category.value === "custom"
          ? this.el.customCategory.value.trim()
          : this.el.category.value;
        const dueDate = this.el.dueDate.value;

        if (!title) {
          this.el.title.setCustomValidity("Please enter a task title.");
          this.el.title.reportValidity();
          this.el.title.addEventListener("input", () => this.el.title.setCustomValidity(""), { once: true });
          return;
        }
        if (!category) {
          this.el.customCategory.setCustomValidity("Enter a custom category.");
          this.el.customCategory.reportValidity();
          this.el.customCategory.addEventListener("input", () => this.el.customCategory.setCustomValidity(""), { once: true });
          return;
        }

        this.tasks.push({
          id: this.createId(), title, category: category.slice(0, 30), dueDate,
          completed: false, createdAt: Date.now(), order: this.tasks.length
        });
        this.saveTasksToStorage();
        this.el.form.reset();
        this.el.customWrap.classList.remove("visible");
        this.showToast("Task added.");
        this.render();
        this.el.title.focus();
      }

      createId() {
        return globalThis.crypto?.randomUUID
          ? crypto.randomUUID()
          : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
      }

      toggleTask(id, completed) {
        const task = this.tasks.find(item => item.id === id);
        if (!task) return;
        task.completed = completed;
        this.saveTasksToStorage();
        this.render();
      }

      saveEdit(id) {
        const form = this.el.list.querySelector(`.edit-form[data-id="${CSS.escape(id)}"]`);
        if (!form) return;
        const title = form.elements.title.value.trim();
        const category = form.elements.category.value.trim();
        const dueDate = form.elements.dueDate.value;
        if (!title || !category) {
          this.showToast("Title and category cannot be empty.");
          return;
        }
        const task = this.tasks.find(item => item.id === id);
        if (!task) return;
        Object.assign(task, { title, category: category.slice(0, 30), dueDate });
        this.editingId = null;
        this.saveTasksToStorage();
        this.showToast("Task updated.");
        this.render();
      }

      deleteTask(id, element) {
        if (element) element.classList.add("removing");
        window.setTimeout(() => {
          this.tasks = this.tasks.filter(task => task.id !== id);
          this.normalizeOrder();
          this.saveTasksToStorage();
          this.render();
          this.showToast("Task deleted.");
        }, 190);
      }

      reorderTask(sourceId, targetId) {
        const visible = this.getVisibleTasks();
        const from = visible.findIndex(task => task.id === sourceId);
        const to = visible.findIndex(task => task.id === targetId);
        if (from < 0 || to < 0 || from === to) return;

        const orderedVisible = [...visible];
        const [moved] = orderedVisible.splice(from, 1);
        orderedVisible.splice(to, 0, moved);

        // Reassign visible positions while retaining hidden tasks in their existing slots.
        const visibleIds = new Set(orderedVisible.map(task => task.id));
        const slots = this.tasks.map((task, index) => visibleIds.has(task.id) ? index : -1).filter(index => index >= 0);
        slots.forEach((slot, index) => { this.tasks[slot] = orderedVisible[index]; });
        this.normalizeOrder();
        this.saveTasksToStorage();
        this.render();
      }

      moveTask(id, direction) {
        const visible = this.getVisibleTasks();
        const index = visible.findIndex(task => task.id === id);
        const target = visible[index + direction];
        if (index < 0 || !target) return;
        this.reorderTask(id, target.id);
      }

      normalizeOrder() {
        this.tasks.forEach((task, index) => { task.order = index; });
      }

      clearDragState() {
        this.draggedId = null;
        this.el.list.querySelectorAll(".dragging, .drag-over").forEach(node =>
          node.classList.remove("dragging", "drag-over")
        );
      }

      getVisibleTasks() {
        return this.tasks
          .filter(task => {
            const matchesFilter = this.filter === "all" ||
              (this.filter === "active" && !task.completed) ||
              (this.filter === "completed" && task.completed);
            const matchesSearch = !this.searchTerm ||
              `${task.title} ${task.category}`.toLocaleLowerCase().includes(this.searchTerm);
            return matchesFilter && matchesSearch;
          })
          .sort((a, b) => a.order - b.order);
      }

      render() {
        const visible = this.getVisibleTasks();
        const total = this.tasks.length;
        const completed = this.tasks.filter(task => task.completed).length;
        const labels = { all: "All tasks", active: "Active tasks", completed: "Completed tasks" };
        this.el.heading.textContent = labels[this.filter];
        this.el.count.textContent = `${visible.length} shown · ${total} total`;
        this.el.list.replaceChildren();

        visible.forEach(task => this.el.list.append(this.createTaskElement(task, visible)));

        const isEmpty = visible.length === 0;
        this.el.empty.hidden = !isEmpty;
        if (isEmpty) {
          if (this.searchTerm) {
            this.el.emptyTitle.textContent = "No matching tasks";
            this.el.emptyMessage.textContent = "Try another search term or clear your search.";
          } else if (this.filter === "active" && total > 0) {
            this.el.emptyTitle.textContent = "All caught up!";
            this.el.emptyMessage.textContent = "You have no active tasks. Enjoy the breathing room.";
          } else if (this.filter === "completed" && completed === 0) {
            this.el.emptyTitle.textContent = "Nothing completed yet";
            this.el.emptyMessage.textContent = "Complete a task and it will appear here.";
          } else {
            this.el.emptyTitle.textContent = "A fresh start";
            this.el.emptyMessage.textContent = "Add your first task above and turn your plans into progress.";
          }
        }
      }

      createTaskElement(task, visibleTasks) {
        const li = document.createElement("li");
        li.className = `task-item${task.completed ? " completed" : ""}`;
        li.dataset.id = task.id;
        li.draggable = !this.editingId;

        if (this.editingId === task.id) {
          li.draggable = false;
          li.append(this.createEditForm(task));
          return li;
        }

        const checkbox = document.createElement("input");
        checkbox.type = "checkbox";
        checkbox.className = "check";
        checkbox.checked = task.completed;
        checkbox.dataset.action = "toggle";
        checkbox.dataset.id = task.id;
        checkbox.setAttribute("aria-label", `Mark "${task.title}" ${task.completed ? "active" : "completed"}`);

        const main = document.createElement("div");
        main.className = "task-main";
        const title = document.createElement("span");
        title.className = "task-title";
        title.textContent = task.title; // textContent prevents HTML/script injection.
        const meta = document.createElement("div");
        meta.className = "task-meta";

        const category = document.createElement("span");
        category.className = `category ${this.categoryClass(task.category)}`;
        category.textContent = task.category;
        meta.append(category);

        if (task.dueDate) {
          const due = document.createElement("span");
          due.className = `due-date${!task.completed && task.dueDate < this.todayISO() ? " overdue" : ""}`;
          due.textContent = `Due ${this.formatDate(task.dueDate)}`;
          meta.append(due);
        }
        main.append(title, meta);

        const actions = document.createElement("div");
        actions.className = "task-actions";
        const position = visibleTasks.findIndex(item => item.id === task.id);
        actions.append(
          this.makeButton("↑", "move-up", task.id, "Move task up", position === 0),
          this.makeButton("↓", "move-down", task.id, "Move task down", position === visibleTasks.length - 1),
          this.makeButton("✎", "edit", task.id, "Edit task"),
          this.makeButton("×", "delete", task.id, "Delete task", false, "delete")
        );
        const handle = document.createElement("span");
        handle.className = "drag-handle";
        handle.textContent = "⠿";
        handle.title = "Drag to reorder";
        handle.setAttribute("aria-hidden", "true");
        actions.prepend(handle);

        li.append(checkbox, main, actions);
        return li;
      }

      createEditForm(task) {
        const form = document.createElement("form");
        form.className = "edit-form";
        form.dataset.id = task.id;

        const title = document.createElement("input");
        title.name = "title";
        title.value = task.title;
        title.maxLength = 180;
        title.setAttribute("aria-label", "Task title");

        const category = document.createElement("input");
        category.name = "category";
        category.value = task.category;
        category.maxLength = 30;
        category.setAttribute("aria-label", "Task category");

        const date = document.createElement("input");
        date.name = "dueDate";
        date.type = "date";
        date.value = task.dueDate || "";
        date.setAttribute("aria-label", "Due date");

        const actions = document.createElement("div");
        actions.className = "edit-actions";
        const save = document.createElement("button");
        save.className = "small-btn";
        save.type = "submit";
        save.textContent = "Save";
        const cancel = document.createElement("button");
        cancel.className = "small-btn secondary";
        cancel.type = "button";
        cancel.dataset.action = "cancel-edit";
        cancel.dataset.id = task.id;
        cancel.textContent = "Cancel";
        actions.append(save, cancel);
        form.append(title, category, date, actions);
        requestAnimationFrame(() => title.focus());
        return form;
      }

      makeButton(label, action, id, ariaLabel, disabled = false, extraClass = "") {
        const button = document.createElement("button");
        button.type = "button";
        button.className = `icon-btn ${extraClass}`.trim();
        button.textContent = label;
        button.dataset.action = action;
        button.dataset.id = id;
        button.setAttribute("aria-label", ariaLabel);
        button.disabled = disabled;
        return button;
      }

      categoryClass(category) {
        const known = category.toLowerCase();
        return ["work", "personal", "study", "health"].includes(known) ? known : "";
      }

      todayISO() {
        const now = new Date();
        const local = new Date(now.getTime() - now.getTimezoneOffset() * 60000);
        return local.toISOString().slice(0, 10);
      }

      formatDate(dateString) {
        const [year, month, day] = dateString.split("-").map(Number);
        const date = new Date(year, month - 1, day);
        return new Intl.DateTimeFormat(undefined, { month: "short", day: "numeric", year: "numeric" }).format(date);
      }

      showToast(message) {
        this.el.toast.textContent = message;
        this.el.toast.classList.add("show");
        window.clearTimeout(this.toastTimer);
        this.toastTimer = window.setTimeout(() => this.el.toast.classList.remove("show"), 2100);
      }
    }

    // The script is placed after the page markup, so all required elements exist.
    document.addEventListener("DOMContentLoaded", () => {
      new TaskManager();
    }, { once: true });
